package com.example.mpcamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Ponto de "pinça" de uma mão, em coordenadas da tela.
 * palm = tamanho da palma relativo à altura da imagem (maior = mão mais perto da câmera).
 */
class Pointer(val x: Float, val y: Float, val pinch: Boolean, val palm: Float)

/** Desenha o esqueleto das mãos, o ponto de pinça e as infos de FPS. */
class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    @Volatile private var hands: List<FloatArray> = emptyList()
    @Volatile private var pointers: Array<Pointer?> = arrayOfNulls(2)
    @Volatile private var info = ""

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 80, 255, 120)
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        strokeWidth = 6f
        style = Paint.Style.STROKE
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 0, 229, 255)
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 38f
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun update(h: List<FloatArray>, p: Array<Pointer?>, infoText: String) {
        hands = h
        pointers = p
        info = infoText
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawText(info, 24f, 64f, textPaint)

        for (pts in hands) {
            var i = 0
            while (i < CONNECTIONS.size) {
                val a = CONNECTIONS[i]
                val b = CONNECTIONS[i + 1]
                canvas.drawLine(pts[a * 2], pts[a * 2 + 1], pts[b * 2], pts[b * 2 + 1], linePaint)
                i += 2
            }
            for (j in 0 until 21) canvas.drawCircle(pts[j * 2], pts[j * 2 + 1], 5f, dotPaint)
        }

        for (p in pointers) {
            if (p == null) continue
            if (p.pinch) canvas.drawCircle(p.x, p.y, 22f, fillPaint)
            else canvas.drawCircle(p.x, p.y, 30f, ringPaint)
        }
    }

    companion object {
        private val CONNECTIONS = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4,
            0, 5, 5, 6, 6, 7, 7, 8,
            5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16,
            13, 17, 17, 18, 18, 19, 19, 20,
            0, 17
        )
    }
}

/**
 * Controla a TV virtual com as mãos:
 *  - pinça em cima da TV      -> segura e arrasta
 *  - pinça com as DUAS mãos   -> aumenta / diminui
 *  - pinça num botão          -> clica
 *  - pinça na barra de tempo  -> pula pro ponto do vídeo (e arrasta)
 */
class TvController(
    private val container: View,
    private val progress: View,
    private val buttons: List<View>,
    private val onSeekFraction: (Float) -> Unit
) {
    private var cx = 0f
    private var cy = 0f
    private var scale = 0.6f
    private var vw = 0f
    private var vh = 0f

    private val prevPinch = BooleanArray(2)
    private var grabIdx = -1
    private var grabOffX = 0f
    private var grabOffY = 0f

    private var scaleMode = false
    private var startDist = 1f
    private var startScale = 1f
    private var scaleOffX = 0f
    private var scaleOffY = 0f

    private var seekIdx = -1

    fun reset(w: Float, h: Float) {
        vw = w
        vh = h
        cx = w / 2f
        cy = h * 0.4f
        scale = 0.6f
        apply()
    }

    private fun apply() {
        cx = cx.coerceIn(0f, vw)
        cy = cy.coerceIn(0f, vh)
        container.translationX = cx - container.width / 2f
        container.translationY = cy - container.height / 2f
        container.scaleX = scale
        container.scaleY = scale
    }

    private fun localX(px: Float) = (px - cx) / scale + container.width / 2f
    private fun localY(py: Float) = (py - cy) / scale + container.height / 2f

    private fun rectIn(v: View): RectF {
        var l = 0f
        var t = 0f
        var cur: View = v
        while (cur !== container) {
            l += cur.left
            t += cur.top
            cur = cur.parent as View
        }
        return RectF(l, t, l + v.width, t + v.height)
    }

    private fun insideTv(lx: Float, ly: Float, margin: Float = 10f) =
        lx >= -margin && ly >= -margin &&
            lx <= container.width + margin && ly <= container.height + margin

    fun process(pointers: Array<Pointer?>, w: Float, h: Float) {
        vw = w
        vh = h
        if (container.width == 0) return

        // 1) início de pinça
        for (i in 0..1) {
            val p = pointers[i]
            val pinching = p?.pinch == true
            if (pinching && !prevPinch[i]) onset(i, p!!, pointers)
            prevPinch[i] = pinching
        }

        // 2) escalar com duas mãos
        if (scaleMode) {
            val a = pointers[0]
            val b = pointers[1]
            if (a?.pinch == true && b?.pinch == true) {
                val d = hypot(a.x - b.x, a.y - b.y)
                scale = (startScale * d / startDist).coerceIn(0.3f, 2.2f)
                val mx = (a.x + b.x) / 2f
                val my = (a.y + b.y) / 2f
                val k = scale / startScale
                cx = mx + scaleOffX * k
                cy = my + scaleOffY * k
            } else {
                scaleMode = false
                grabIdx = -1
            }
        } else if (grabIdx >= 0) {
            // 3) arrastar com uma mão
            val p = pointers[grabIdx]
            if (p?.pinch == true) {
                cx = p.x + grabOffX
                cy = p.y + grabOffY
            } else grabIdx = -1
        }

        // 4) arrastar a barra de tempo
        if (seekIdx >= 0) {
            val p = pointers[seekIdx]
            if (p?.pinch == true) seekTo(localX(p.x)) else seekIdx = -1
        }

        apply()
    }

    private fun seekTo(lx: Float) {
        val r = rectIn(progress)
        onSeekFraction(((lx - r.left) / r.width()).coerceIn(0f, 1f))
    }

    private fun onset(i: Int, p: Pointer, pointers: Array<Pointer?>) {
        val j = 1 - i
        val other = pointers[j]

        // segunda mão pinçando enquanto a outra segura a TV -> modo escala
        if (other?.pinch == true && grabIdx == j && !scaleMode) {
            scaleMode = true
            startDist = hypot(p.x - other.x, p.y - other.y).coerceAtLeast(40f)
            startScale = scale
            val mx = (p.x + other.x) / 2f
            val my = (p.y + other.y) / 2f
            scaleOffX = cx - mx
            scaleOffY = cy - my
            return
        }

        val lx = localX(p.x)
        val ly = localY(p.y)
        if (!insideTv(lx, ly)) return

        for (b in buttons) {
            if (rectIn(b).contains(lx, ly)) {
                b.performClick()
                return
            }
        }

        val pr = rectIn(progress)
        if (lx >= pr.left && lx <= pr.right && ly >= pr.top - 10f && ly <= pr.bottom + 10f) {
            seekIdx = i
            seekTo(lx)
            return
        }

        grabIdx = i
        grabOffX = cx - p.x
        grabOffY = cy - p.y
    }
}

/**
 * Pintura 3D com a mão.
 *  - Pinça = pinta. A profundidade (Z) vem do tamanho da palma: mão perto = Z pequeno.
 *  - Os traços ficam guardados em 3D e são projetados com uma câmera orbital,
 *    então dá pra girar a cena (arrastando na tela ou no modo "Girar" com a pinça).
 */
class PaintView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private class Stroke(val color: Int, val width: Float) {
        var data = FloatArray(96)
        var n = 0
        fun add(x: Float, y: Float, z: Float) {
            if (n * 3 + 3 > data.size) data = data.copyOf(data.size * 2)
            data[n * 3] = x
            data[n * 3 + 1] = y
            data[n * 3 + 2] = z
            n++
        }
    }

    var color: Int = Color.parseColor("#FF3B30")
    var brushWidth = 12f
    var darkBackground = false
        set(v) {
            field = v
            invalidate()
        }
    var rotateMode = false
        set(v) {
            field = v
            endStroke()
            lastPx = Float.NaN
        }

    private val strokes = ArrayList<Stroke>()
    private var current: Stroke? = null
    private var totalPoints = 0

    private var yaw = 0f
    private var pitch = 0f

    private var smX = 0f
    private var smY = 0f
    private var smZ = 1f
    private var lastPx = Float.NaN
    private var lastPy = 0f
    private var tx = 0f
    private var ty = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // ---------- API ----------
    fun undo() {
        current = null
        if (strokes.isNotEmpty()) {
            val s = strokes.removeAt(strokes.size - 1)
            totalPoints -= s.n
        }
        invalidate()
    }

    fun clear() {
        current = null
        strokes.clear()
        totalPoints = 0
        invalidate()
    }

    fun resetView() {
        yaw = 0f
        pitch = 0f
        invalidate()
    }

    private fun endStroke() {
        current = null
    }

    // ---------- entrada pela mão ----------
    fun update(pointers: Array<Pointer?>) {
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vh == 0f) return

        val idx = when {
            pointers[0]?.pinch == true -> 0
            pointers[1]?.pinch == true -> 1
            else -> -1
        }
        if (idx < 0) {
            endStroke()
            lastPx = Float.NaN
            return
        }
        val p = pointers[idx]!!

        if (rotateMode) {
            if (!lastPx.isNaN()) {
                yaw -= (p.x - lastPx) * 0.006f
                pitch = (pitch + (p.y - lastPy) * 0.006f).coerceIn(-1.4f, 1.4f)
            }
            lastPx = p.x
            lastPy = p.y
            invalidate()
            return
        }

        val depth = (REF_PALM / max(p.palm, 0.02f)).coerceIn(0.35f, 3f)
        val cx = (p.x - vw / 2f) / vh * depth
        val cy = (p.y - vh / 2f) / vh * depth

        var s = current
        if (s == null) {
            smX = cx
            smY = cy
            smZ = depth
            s = Stroke(color, brushWidth)
            current = s
            strokes.add(s)
        } else {
            smX += (cx - smX) * 0.6f
            smY += (cy - smY) * 0.6f
            smZ += (depth - smZ) * 0.25f
        }

        val w = toWorld(smX, smY, smZ)
        if (s.n > 0) {
            val dx = w[0] - s.data[(s.n - 1) * 3]
            val dy = w[1] - s.data[(s.n - 1) * 3 + 1]
            val dz = w[2] - s.data[(s.n - 1) * 3 + 2]
            if (dx * dx + dy * dy + dz * dz < MIN_DIST2) {
                invalidate()
                return
            }
        }
        if (totalPoints < MAX_POINTS) {
            s.add(w[0], w[1], w[2])
            totalPoints++
        }
        invalidate()
    }

    // ---------- entrada por toque (girar a cena) ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tx = e.x
                ty = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                yaw -= (e.x - tx) * 0.006f
                pitch = (pitch + (e.y - ty) * 0.006f).coerceIn(-1.4f, 1.4f)
                tx = e.x
                ty = e.y
                invalidate()
            }
        }
        return true
    }

    // ---------- matemática 3D ----------
    // espaço da câmera -> espaço do mundo (desfaz a rotação orbital em torno do pivô)
    private fun toWorld(x: Float, y: Float, z: Float): FloatArray {
        val pz = z - PIVOT_Z
        val cX = cos(pitch)
        val sX = sin(pitch)
        val cY = cos(yaw)
        val sY = sin(yaw)
        val y1 = y * cX + pz * sX
        val z1 = -y * sX + pz * cX
        val x2 = x * cY - z1 * sY
        val z2 = x * sY + z1 * cY
        return floatArrayOf(x2, y1, z2 + PIVOT_Z)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (darkBackground) canvas.drawColor(Color.BLACK)

        val vw = width.toFloat()
        val vh = height.toFloat()
        val cX = cos(pitch)
        val sX = sin(pitch)
        val cY = cos(yaw)
        val sY = sin(yaw)

        for (s in strokes) {
            var hasPrev = false
            var prevX = 0f
            var prevY = 0f
            var prevZ = 0f
            for (i in 0 until s.n) {
                val x = s.data[i * 3]
                val y = s.data[i * 3 + 1]
                val rz = s.data[i * 3 + 2] - PIVOT_Z

                val x1 = x * cY + rz * sY
                val z1 = -x * sY + rz * cY
                val y2 = y * cX - z1 * sX
                val z2 = y * sX + z1 * cX + PIVOT_Z

                if (z2 < 0.15f) {
                    hasPrev = false
                    continue
                }
                val px = x1 / z2 * vh + vw / 2f
                val py = y2 / z2 * vh + vh / 2f

                val shade = (1.6f - z2 * 0.6f).coerceIn(0.35f, 1f)
                if (hasPrev) {
                    val zAvg = (z2 + prevZ) / 2f
                    paint.color = s.color
                    paint.alpha = (255 * shade).toInt()
                    paint.strokeWidth = (s.width / zAvg).coerceIn(1.5f, 90f)
                    canvas.drawLine(prevX, prevY, px, py, paint)
                } else if (s.n == 1) {
                    dotPaint.color = s.color
                    dotPaint.alpha = (255 * shade).toInt()
                    canvas.drawCircle(px, py, (s.width / z2).coerceIn(1.5f, 90f) / 2f, dotPaint)
                }
                hasPrev = true
                prevX = px
                prevY = py
                prevZ = z2
            }
        }
    }

    companion object {
        private const val PIVOT_Z = 1f
        private const val REF_PALM = 0.25f
        private const val MIN_DIST2 = 0.003f * 0.003f
        private const val MAX_POINTS = 60000
    }
}
